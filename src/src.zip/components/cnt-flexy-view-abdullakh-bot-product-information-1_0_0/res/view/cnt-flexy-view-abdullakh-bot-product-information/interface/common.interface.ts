/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface SSAbdullakhProductInformation {
  title: string;
  infoBlock: any;
}
