# s-abdullakh-tariffs-info-blocks



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                                            | Type  | Default     |
| -------- | --------- | ------------------------------------------------------ | ----- | ----------- |
| `arr`    | `arr`     | данные переданные методом map компоненту TariffsBlocks | `any` | `undefined` |


## Events

| Event            | Description                          | Type               |
| ---------------- | ------------------------------------ | ------------------ |
| `clickOnTariffs` | клик по элементам компонента Tariffs | `CustomEvent<any>` |
| `openForm`       | Вызов модального окна формы          | `CustomEvent<any>` |


## Dependencies

### Used by

 - [cnt-flexy-view-abdullakh-bot-tariffs](../../..)

### Graph
```mermaid
graph TD;
  cnt-flexy-view-abdullakh-bot-tariffs --> s-abdullakh-tariffs-info-blocks
  style s-abdullakh-tariffs-info-blocks fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
