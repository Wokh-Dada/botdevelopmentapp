/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface SSAbdullakhTariffs {
  dinamicImg: string;
  dinamicText: string;
  title: string;
  bckgrndImg: string;
  infoBlock: any;
}
