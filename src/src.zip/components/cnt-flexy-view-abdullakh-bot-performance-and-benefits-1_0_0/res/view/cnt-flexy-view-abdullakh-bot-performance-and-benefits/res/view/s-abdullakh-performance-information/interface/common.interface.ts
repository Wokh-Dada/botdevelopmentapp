/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface SSAbdullakhPerformanceInformation {
  imgUrl: string;
  title: string;
  ContentRightEndText: string;
  ContentLeftEndText: string;
  btnText: string;
  right: any;
  left: any;
}
