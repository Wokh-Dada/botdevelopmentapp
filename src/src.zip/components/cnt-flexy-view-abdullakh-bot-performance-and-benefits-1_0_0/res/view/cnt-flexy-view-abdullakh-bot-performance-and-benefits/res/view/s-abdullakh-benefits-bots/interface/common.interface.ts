/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface SSAbdullakhBenefitsBots {
  title: string;
  infoBlock: any;
}
