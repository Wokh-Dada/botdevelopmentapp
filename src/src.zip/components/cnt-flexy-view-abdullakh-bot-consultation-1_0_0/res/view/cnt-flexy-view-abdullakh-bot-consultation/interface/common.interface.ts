/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface SSAbdullakhConsultation {
  imgUrl: string;
  title: string;
  text: string;
  btnText: string;
}
