# cnt-flexy-view-bot-abdullakh-header-1_0_0



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute    | Description                                                                | Type  | Default     |
| ------------ | ------------ | -------------------------------------------------------------------------- | ----- | ----------- |
| `categories` | `categories` | объект с массивом меню и string для подкомпонентов header-start header-end | `any` | `undefined` |


## Dependencies

### Used by

 - [my-component](../my-component)

### Depends on

- [cnt-flexy-view-bot-abdullakh-header](res/view/cnt-flexy-view-abdullakh-bot-header)

### Graph
```mermaid
graph TD;
  cnt-flexy-view-bot-abdullakh-header-1_0_0 --> cnt-flexy-view-bot-abdullakh-header
  cnt-flexy-view-bot-abdullakh-header --> s-abdullakh-header-start
  cnt-flexy-view-bot-abdullakh-header --> s-abdullakh-header-end
  cnt-flexy-view-bot-abdullakh-header --> s-abdullakh-header-center
  my-component --> cnt-flexy-view-bot-abdullakh-header-1_0_0
  style cnt-flexy-view-bot-abdullakh-header-1_0_0 fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
