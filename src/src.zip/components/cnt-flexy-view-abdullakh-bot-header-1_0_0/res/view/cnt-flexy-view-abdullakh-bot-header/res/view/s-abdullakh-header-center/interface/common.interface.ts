/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface AbdullakhHeaderCenter {
  id: string;
  linkName: string;
  menuLine: string;
}
