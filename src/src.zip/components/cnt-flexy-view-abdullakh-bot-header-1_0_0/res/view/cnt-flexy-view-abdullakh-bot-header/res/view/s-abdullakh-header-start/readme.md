# s-abdullakh-header-start



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description       | Type  | Default     |
| -------- | --------- | ----------------- | ----- | ----------- |
| `logo`   | `logo`    | объект с url logo | `any` | `undefined` |


## Events

| Event           | Description                                    | Type               |
| --------------- | ---------------------------------------------- | ------------------ |
| `clickOnHeader` | клик по элементу HeaderStart компонента header | `CustomEvent<any>` |


## Dependencies

### Used by

 - [cnt-flexy-view-bot-abdullakh-header](../../..)

### Graph
```mermaid
graph TD;
  cnt-flexy-view-bot-abdullakh-header --> s-abdullakh-header-start
  style s-abdullakh-header-start fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
