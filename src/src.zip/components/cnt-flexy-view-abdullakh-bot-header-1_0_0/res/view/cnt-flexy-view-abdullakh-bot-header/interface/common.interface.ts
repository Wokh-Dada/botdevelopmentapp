/*
*  interface для объекта с массивом меню и string для подкомпонентов header-start header-end
* */

export interface CntFlexyViewCategoryForOwnerItemInterface  {
  id: string;
  logoUrl: string;
  phoneNumber: string;
  menu: object;
}
