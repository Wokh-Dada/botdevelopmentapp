# s-abdullakh-form



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                           | Type  | Default     |
| -------- | --------- | ------------------------------------- | ----- | ----------- |
| `arr`    | `arr`     | данные из массива для компонента Form | `any` | `undefined` |


## Dependencies

### Used by

 - [cnt-flexy-view-bot-abdullakh-form-communication](../../..)

### Graph
```mermaid
graph TD;
  cnt-flexy-view-bot-abdullakh-form-communication --> s-abdullakh-form
  style s-abdullakh-form fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
