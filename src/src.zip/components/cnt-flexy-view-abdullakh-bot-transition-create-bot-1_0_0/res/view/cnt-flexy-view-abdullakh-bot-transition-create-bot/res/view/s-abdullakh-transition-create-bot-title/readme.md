# s-abdullakh-transition-create-bot-title



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                                                                                       | Type  | Default     |
| -------- | --------- | ------------------------------------------------------------------------------------------------- | ----- | ----------- |
| `arr`    | `arr`     | массив для вывода элементов подкомпонента TransitionCreateBotTitle компонента TransitionCreateBot | `any` | `undefined` |


## Events

| Event                        | Description                                      | Type               |
| ---------------------------- | ------------------------------------------------ | ------------------ |
| `clickOnTransitionCreateBot` | клик по элементам компонента TransitionCreateBot | `CustomEvent<any>` |


## Dependencies

### Used by

 - [cnt-flexy-view-abdullakh-bot-transition-create-bot](../../..)

### Graph
```mermaid
graph TD;
  cnt-flexy-view-abdullakh-bot-transition-create-bot --> s-abdullakh-transition-create-bot-title
  style s-abdullakh-transition-create-bot-title fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
